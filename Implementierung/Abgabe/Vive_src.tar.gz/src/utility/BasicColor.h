#ifndef __BasicColor_h__
#define __BasicColor_h__

namespace Model {
// enum BasicColor;
}

namespace Model {
enum BasicColor {
	RED,
	GREEN,
	BLUE
};
}

#endif

