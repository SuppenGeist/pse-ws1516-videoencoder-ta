
#ifndef __NoiseMode_h__
#define __NoiseMode_h__


namespace Model {
enum NoiseMode {
	STATIC,
	RANDOM,
	MUSTER
};
}

#endif

