
#ifndef __MirrorMode_h__
#define __MirrorMode_h__


namespace Model {
enum MirrorMode {
	HORIZONTAL,
	VERTICAL
};
}

#endif

