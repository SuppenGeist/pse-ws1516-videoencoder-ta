#ifndef ANALYSISVIDEO
#define ANALYSISVIDEO

namespace GUI {
enum class AnalysisVideo {
    MACROBLOCK,
    RGB_DIFFERENCE
};
}

#endif // ANALYSISVIDEO

