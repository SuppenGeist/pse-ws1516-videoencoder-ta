#include "PlainFilterBox.h"

#include <QWidget>

#include "FilterConfigurationBox.h"

GUI::PlainFilterBox::PlainFilterBox(QWidget* parent):FilterConfigurationBox(parent) {
	hide();
}

void GUI::PlainFilterBox::updateUi() {

}
